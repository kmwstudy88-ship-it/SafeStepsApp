export const safeStepsTheme = {
  colors: {
    teal900: '#073F45',
    teal700: '#09666B',
    teal500: '#13858A',
    teal100: '#DCEEEE',
    sage600: '#69866F',
    sage300: '#B8C9AE',
    sage100: '#E8EFDF',
    cream: '#FFFDF7',
    white: '#FFFFFF',
    gold500: '#D69B22',
    gold300: '#F1C66B',
    gold100: '#FFF3D6',
    sky: '#A9D6E8',
    blush: '#F1B8B7',
    lavender: '#C9B7E5',
    peach: '#F5C99B',
    text: '#073F45',
    textMuted: '#526A6C',
    border: '#DFE7DC',
    danger: '#A64B4B',
    success: '#397654',
  },
  radius: { sm: 10, md: 16, lg: 24, pill: 999 },
  space: { xs: 4, sm: 8, md: 12, lg: 16, xl: 24, xxl: 32 },
  shadow: {
    card: {
      shadowColor: '#073F45', shadowOpacity: 0.08,
      shadowRadius: 12, shadowOffset: { width: 0, height: 5 }, elevation: 3,
    },
  },
} as const;

export type SafeStepsTheme = typeof safeStepsTheme;
