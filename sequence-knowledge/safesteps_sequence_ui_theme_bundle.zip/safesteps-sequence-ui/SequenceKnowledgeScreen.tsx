import React, { useMemo, useState } from 'react';
import {
  Alert, Pressable, SafeAreaView, ScrollView, StatusBar,
  StyleSheet, Text, View,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { safeStepsTheme as t } from './theme';

export type SequenceStep = {
  id: string;
  text: string;
  kind: 'correct_step' | 'distractor';
};

type Props = {
  questionNumber?: number;
  totalQuestions?: number;
  onBack?: () => void;
  onSubmit?: (selectedSequence: string[], excludedIds: string[]) => void;
};

const INITIAL_STEPS: SequenceStep[] = [
  { id: 'C1', text: 'Check whether the child is immediately safe', kind: 'correct_step' },
  { id: 'C2', text: 'Approach calmly and offer reassurance', kind: 'correct_step' },
  { id: 'D1', text: 'Ask the child to explain every detail immediately', kind: 'distractor' },
  { id: 'C3', text: 'Listen and acknowledge their experience', kind: 'correct_step' },
  { id: 'C4', text: 'Help the child choose a calming strategy', kind: 'correct_step' },
  { id: 'C5', text: 'Discuss solutions once the child feels safer', kind: 'correct_step' },
];

function WatercolourBackground() {
  return (
    <View pointerEvents="none" style={StyleSheet.absoluteFill}>
      <View style={[styles.wash, styles.washSage]} />
      <View style={[styles.wash, styles.washBlue]} />
      <View style={[styles.wash, styles.washBlush]} />
      <View style={[styles.wash, styles.washLavender]} />
      <View style={[styles.wash, styles.washPeach]} />
      <View style={styles.goldDropOne} />
      <View style={styles.goldDropTwo} />
    </View>
  );
}

export default function SequenceKnowledgeScreen({
  questionNumber = 12,
  totalQuestions = 50,
  onBack,
  onSubmit,
}: Props) {
  const [ordered, setOrdered] = useState(() =>
    INITIAL_STEPS.filter(step => step.kind === 'correct_step'),
  );
  const [excluded, setExcluded] = useState(() =>
    INITIAL_STEPS.filter(step => step.kind === 'distractor'),
  );
  const progress = Math.max(0, Math.min(1, questionNumber / totalQuestions));

  const canSubmit = useMemo(
    () => ordered.length > 0 && excluded.length > 0,
    [ordered.length, excluded.length],
  );

  function moveStep(index: number, direction: -1 | 1) {
    const destination = index + direction;
    if (destination < 0 || destination >= ordered.length) return;
    setOrdered(current => {
      const next = [...current];
      [next[index], next[destination]] = [next[destination], next[index]];
      return next;
    });
  }

  function leaveOut(step: SequenceStep) {
    setOrdered(current => current.filter(item => item.id !== step.id));
    setExcluded(current => [...current, step]);
  }

  function putBack(step: SequenceStep) {
    setExcluded(current => current.filter(item => item.id !== step.id));
    setOrdered(current => [...current, step]);
  }

  function submit() {
    if (!canSubmit) {
      Alert.alert('Check your response', 'Place the helpful actions in order and leave out any unsuitable action.');
      return;
    }
    onSubmit?.(ordered.map(step => step.id), excluded.map(step => step.id));
  }

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="dark-content" backgroundColor={t.colors.cream} />
      <WatercolourBackground />
      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <Pressable onPress={onBack} hitSlop={12} style={styles.iconButton} accessibilityRole="button" accessibilityLabel="Go back">
            <Ionicons name="arrow-back" size={28} color={t.colors.teal700} />
          </Pressable>
          <View style={styles.brand}>
            <View style={styles.logoMark}><Ionicons name="leaf" size={22} color={t.colors.white} /></View>
            <Text style={styles.brandText}>SafeSteps</Text>
          </View>
          <View style={styles.headerSpacer} />
        </View>

        <View style={styles.questionRow}>
          <Text style={styles.questionCount}>Question {questionNumber} of {totalQuestions}</Text>
          <Text style={styles.percent}>{Math.round(progress * 100)}%</Text>
        </View>
        <View style={styles.progressTrack} accessibilityRole="progressbar" accessibilityValue={{ min: 0, max: totalQuestions, now: questionNumber }}>
          <View style={[styles.progressFill, { width: `${progress * 100}%` }]} />
        </View>

        <View style={styles.categoryPill}><Text style={styles.categoryText}>SEQUENCE KNOWLEDGE</Text></View>
        <Text style={styles.heading}>What should happen first?</Text>

        <View style={styles.scenarioCard}>
          <View style={styles.scenarioIcon}><Ionicons name="home-outline" size={30} color={t.colors.teal700} /></View>
          <Text style={styles.scenarioText}>A child arrives home from school upset after a conflict with a friend.</Text>
        </View>
        <Text style={styles.instruction}>Arrange the safe response and leave out actions that do not belong.</Text>

        <View style={styles.list}>
          {ordered.map((step, index) => (
            <View key={step.id} style={styles.stepCard}>
              <View style={styles.numberCircle}><Text style={styles.numberText}>{index + 1}</Text></View>
              <Text style={styles.stepText}>{step.text}</Text>
              <View style={styles.stepActions}>
                <Ionicons name="reorder-three-outline" size={23} color={t.colors.teal500} />
                <View style={styles.arrowColumn}>
                  <Pressable onPress={() => moveStep(index, -1)} disabled={index === 0} hitSlop={8} accessibilityLabel={`Move ${step.text} up`}>
                    <Ionicons name="chevron-up" size={22} color={index === 0 ? t.colors.border : t.colors.teal700} />
                  </Pressable>
                  <Pressable onPress={() => moveStep(index, 1)} disabled={index === ordered.length - 1} hitSlop={8} accessibilityLabel={`Move ${step.text} down`}>
                    <Ionicons name="chevron-down" size={22} color={index === ordered.length - 1 ? t.colors.border : t.colors.teal700} />
                  </Pressable>
                </View>
              </View>
              <Pressable onPress={() => leaveOut(step)} style={styles.leaveLink} accessibilityRole="button">
                <Text style={styles.leaveLinkText}>Leave out</Text>
              </Pressable>
            </View>
          ))}
        </View>

        <View style={styles.leaveSection}>
          <View style={styles.leaveTitleRow}><View style={styles.dash} /><Text style={styles.leaveTitle}>LEAVE OUT</Text><View style={styles.dash} /></View>
          {excluded.map(step => (
            <View key={step.id} style={styles.excludedCard}>
              <View style={styles.minusCircle}><Text style={styles.minusText}>−</Text></View>
              <Text style={styles.stepText}>{step.text}</Text>
              <Pressable onPress={() => putBack(step)} hitSlop={10} accessibilityRole="button" accessibilityLabel={`Put back ${step.text}`}>
                <Ionicons name="return-up-back" size={24} color={t.colors.gold500} />
              </Pressable>
            </View>
          ))}
        </View>

        <Pressable onPress={submit} disabled={!canSubmit} style={({ pressed }) => [styles.submitButton, pressed && styles.submitPressed, !canSubmit && styles.submitDisabled]} accessibilityRole="button">
          <Text style={styles.submitText}>Check my answer</Text>
        </Pressable>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: t.colors.cream },
  scrollContent: { paddingHorizontal: 18, paddingTop: 8, paddingBottom: 40 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 22 },
  iconButton: { width: 44, height: 44, justifyContent: 'center' },
  brand: { flexDirection: 'row', alignItems: 'center', gap: 9 },
  logoMark: { width: 38, height: 38, borderRadius: 19, alignItems: 'center', justifyContent: 'center', backgroundColor: t.colors.teal700 },
  brandText: { color: t.colors.teal900, fontSize: 30, fontWeight: '700', letterSpacing: -0.7 },
  headerSpacer: { width: 44 },
  questionRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  questionCount: { color: t.colors.teal900, fontSize: 16, fontWeight: '600' },
  percent: { color: t.colors.textMuted, fontSize: 13, fontWeight: '600' },
  progressTrack: { height: 7, borderRadius: t.radius.pill, backgroundColor: t.colors.teal100, overflow: 'hidden', marginTop: 9, marginBottom: 26 },
  progressFill: { height: '100%', borderRadius: t.radius.pill, backgroundColor: t.colors.teal700 },
  categoryPill: { alignSelf: 'flex-start', paddingHorizontal: 13, paddingVertical: 7, borderRadius: 8, backgroundColor: t.colors.sage100 },
  categoryText: { color: t.colors.teal900, fontSize: 12, fontWeight: '700', letterSpacing: 1.4 },
  heading: { color: t.colors.teal900, fontSize: 31, lineHeight: 38, fontWeight: '700', marginTop: 14, marginBottom: 18 },
  scenarioCard: { flexDirection: 'row', alignItems: 'center', gap: 14, padding: 16, borderWidth: 1, borderColor: t.colors.border, borderRadius: t.radius.md, backgroundColor: 'rgba(255,253,247,0.92)', ...t.shadow.card },
  scenarioIcon: { width: 58, height: 58, borderRadius: 29, alignItems: 'center', justifyContent: 'center', backgroundColor: t.colors.sage100 },
  scenarioText: { flex: 1, color: t.colors.text, fontSize: 17, lineHeight: 24, fontWeight: '500' },
  instruction: { color: t.colors.text, fontSize: 16, lineHeight: 23, fontWeight: '500', marginVertical: 16 },
  list: { gap: 10 },
  stepCard: { position: 'relative', minHeight: 86, flexDirection: 'row', alignItems: 'center', gap: 12, padding: 13, paddingBottom: 24, borderWidth: 1.5, borderColor: t.colors.gold300, borderRadius: t.radius.md, backgroundColor: 'rgba(255,255,255,0.95)' },
  numberCircle: { width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center', backgroundColor: t.colors.sage100, borderWidth: 1, borderColor: t.colors.sage300 },
  numberText: { color: t.colors.teal900, fontSize: 23, fontWeight: '700' },
  stepText: { flex: 1, color: t.colors.text, fontSize: 16, lineHeight: 22, fontWeight: '500' },
  stepActions: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  arrowColumn: { gap: 4, paddingLeft: 5, borderLeftWidth: 1, borderLeftColor: t.colors.border },
  leaveLink: { position: 'absolute', left: 69, bottom: 5, paddingVertical: 2 },
  leaveLinkText: { color: t.colors.textMuted, fontSize: 12, textDecorationLine: 'underline' },
  leaveSection: { marginTop: 20 },
  leaveTitleRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 10 },
  dash: { flex: 1, height: 1, backgroundColor: t.colors.gold500 },
  leaveTitle: { color: t.colors.gold500, fontSize: 14, fontWeight: '700', letterSpacing: 1.4 },
  excludedCard: { minHeight: 82, flexDirection: 'row', alignItems: 'center', gap: 12, padding: 14, borderWidth: 1.5, borderStyle: 'dashed', borderColor: t.colors.gold500, borderRadius: t.radius.md, backgroundColor: 'rgba(255,253,247,0.96)' },
  minusCircle: { width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center', backgroundColor: t.colors.gold100, borderWidth: 1, borderColor: t.colors.gold300 },
  minusText: { color: t.colors.gold500, fontSize: 28, lineHeight: 30 },
  submitButton: { minHeight: 58, alignItems: 'center', justifyContent: 'center', borderRadius: t.radius.md, backgroundColor: t.colors.teal700, marginTop: 24, ...t.shadow.card },
  submitPressed: { opacity: 0.88, transform: [{ scale: 0.995 }] },
  submitDisabled: { opacity: 0.45 },
  submitText: { color: t.colors.white, fontSize: 18, fontWeight: '700' },
  wash: { position: 'absolute', borderRadius: t.radius.pill, opacity: 0.23 },
  washSage: { width: 230, height: 230, top: -95, left: -80, backgroundColor: t.colors.sage300, transform: [{ rotate: '-12deg' }] },
  washBlue: { width: 160, height: 210, top: 135, right: -105, backgroundColor: t.colors.sky, transform: [{ rotate: '18deg' }] },
  washBlush: { width: 180, height: 160, top: -70, right: -50, backgroundColor: t.colors.blush },
  washLavender: { width: 180, height: 180, bottom: 110, left: -125, backgroundColor: t.colors.lavender },
  washPeach: { width: 145, height: 185, bottom: -90, right: -70, backgroundColor: t.colors.peach },
  goldDropOne: { position: 'absolute', top: 74, right: 36, width: 7, height: 7, borderRadius: 4, backgroundColor: t.colors.gold300, opacity: 0.55 },
  goldDropTwo: { position: 'absolute', top: 96, right: 22, width: 4, height: 4, borderRadius: 2, backgroundColor: t.colors.gold500, opacity: 0.4 },
});
