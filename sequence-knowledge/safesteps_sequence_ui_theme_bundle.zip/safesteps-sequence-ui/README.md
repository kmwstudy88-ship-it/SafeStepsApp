# SafeSteps Sequence Knowledge UI

Expo React Native/TypeScript implementation of the sequence-assessment mockup.

## Add to the app

1. Copy `theme.ts` into your shared theme folder.
2. Copy `SequenceKnowledgeScreen.tsx` into your assessment screens folder.
3. Render `<SequenceKnowledgeScreen />` from an Expo Router route.

The screen uses `@expo/vector-icons`, included in standard Expo projects. Replace `INITIAL_STEPS` with the selected assessment’s `items`. Pass the ordered IDs and excluded IDs from `onSubmit` to trusted scoring code so answer keys remain off the mobile client.
